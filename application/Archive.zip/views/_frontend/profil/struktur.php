

     <!-- ======= Breadcrumbs ======= -->
     <section id="breadcrumbs" class="breadcrumbs">
        <div class="container">

            <ol>
                <li><a href="<?php echo site_url('home')?>">Home</a></li>
                <li><a href="#">Profil</a></li>
                <li><a href="#">Struktur Organisasi</a></li>
            </ol>
            <h2>Struktur Organisasi</h2>

        </div>
    </section><!-- End Breadcrumbs -->
    <main id="main">
       
        <section id="services" class="services">
            <div class="container" data-aos="fade-up">
                <div class="row">
                    <div class="col-lg-12">
                        <img src="<?php echo base_url();?>upload/content/<?php echo $content[0]->content_image;?>" width="100%">
                    </div>
                </div>
            </div>
        </section>
    </main><!-- End #main -->